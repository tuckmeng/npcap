#!/bin/sh
acefile=ACE.txt
appfile="${1}.txt"
app=$1
app_email_file="${app}-EMAIL.txt"
# Usage
echo "Usage: $0 APPNAME"
echo "Application name is ${app}"
echo "This program emails the administrator of application ${app} the IDs that do not exist in ACE."
echo "The ids in application $1 must be in the file ${appfile}"
echo "The ids in ACE must be in the file ${acefile}"
echo "The email addresses of administrators of application ${app} must be in ${app}-ADMIN.txt"
# Sort and Uniq first
sort $acefile |uniq > "ORDER-${acefile}"
sort $appfile | uniq > "ORDER-${appfile}"
diff "ORDER-${acefile}" "ORDER-${appfile}" 2>&1 | grep ">" > ids2delete
echo "From: car-admin@nparks.gov.sg" > $app_email_file
echo -n "To: " >> $app_email_file
cat ${app}-ADMIN.txt >> $app_email_file
echo "Subject: IDs to delete from ${app} as they do not exist in ACE" >> ${app_email_file}
echo "Dear Admin of ${app},">> ${app_email_file}
echo "" >> ${app_email_file}
echo "The following IDs should be removed from ${app} as they do not exist in ACE:" >> ${app_email_file}
echo "" >> ${app_email_file}
sed -i "s/> //g" ids2delete
nl -w 4 -s ". " ids2delete >> ${app_email_file}
echo "" >> ${app_email_file}
echo "Regards,"  >> ${app_email_file}
echo "Car Administrator"  >> ${app_email_file}
# Need to send email in APP_EMAIL.txt
echo "Email to send is in ${app_email_file}"
echo ""
echo "Now modify the script file to send out ${app_email_file} via SMTP server using the mail command by calling a script with the ${app_email_file} as parameter"
echo ""
echo "Debug - See email file ${app_email_file}"
echo "======================================"
cat ${app_email_file}
echo "======================================"
# Cleanup
rm ids2delete
rm ORDER-${acefile}
rm ORDER-${appfile}
